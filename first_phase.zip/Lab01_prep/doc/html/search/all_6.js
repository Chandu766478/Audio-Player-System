var searchData=
[
  ['write',['write',['../class_c_i_o_warrior.html#a25b7f9790c38fcbb72856357596cf406',1,'CIOWarrior']]]
];
