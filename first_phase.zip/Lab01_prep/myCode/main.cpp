////////////////////////////////////////////////////////////////////////////////
// IOWarrior control class
// test program
////////////////////////////////////////////////////////////////////////////////
/**
 * \file main.cpp
 *
 * \brief provides the test cases for the IOWarrior control class.
 */
#include <iostream>
#include<algorithm>
using namespace std;
#include "CIOWarrior.h"
#include "CAmpMeter.h"

/**
 * \brief Test of the basic functionality of the class.
 */
void iow_basic_test();

/**
 * \brief Test of the classes state machine.
 * The device has to be connected at start time, because the API doesn't recognize a newly plugged device during runtime of the program.
 * During runtime (duration is about 12 cycles of the running light) the device may be unplugged and plugged again.
 * If the device is unplugged, the data are printed on the screen (binary format). If it is plugged again, the running light continues.
 */
void iow_runningLight_test();
void button_test_2();
void CAmpmeter_test_1();


int main (void)
{
	setvbuf(stdout, NULL, _IONBF, 0);
	cout << "IOWarrior output test started." << endl << endl;
	//iow_basic_test();
	//iow_runningLight_test();
	//button_test_2();
	CAmpmeter_test_1();
	cout << "Bye!" << endl << endl;
	return 0;
}

void iow_basic_test()
{
	CIOWarrior myWarrior;
	cout << "basic test" << endl;
	cout << "Object state after creation" << endl;
	myWarrior.printState();
	cout << "Try to write before open" << endl;
	myWarrior.write(0xf0);
	myWarrior.printState();

	myWarrior.open();
	cout << "Object state after open" << endl;
	myWarrior.printState();
	cout << "Try to write after open" << endl;
	myWarrior.write(0xf0);
	myWarrior.printState();
	cout << "Object state after close" << endl;
	myWarrior.close();
	myWarrior.printState();
	cout << endl;
}

void iow_runningLight_test()
{
	cout << "running light test" << endl;
	CIOWarrior myWarrior;
	bool bWarrior=true;

	if(false == myWarrior.open())
	{
		cout << "Can only print data! Please, make sure that an IOWarrior 40 is connected at start time!" << endl;
		myWarrior.printState();
		bWarrior=false;
	}

	char data=1;
	for(int i=0; i<=100; i++)
	{
		if(false == bWarrior)
		{
			myWarrior.printData(data); 		// print LED data, no device connected at start time
		}
		else if (false == myWarrior.write(data))	// if write fails (tested by unplugging and plugging the device)
		{
			myWarrior.printData(data); 		// print LED data
			myWarrior.open();				// try to reopen the device
		}
		Sleep(250);
		data=data << 1;
		if(0==data)data=1;
	}
	myWarrior.close();
}
void button_test_1()
{
	cout << "Button test 1- button starts the running light!!" << endl;
	cout<<"press the button to start running light"<<endl;

	CIOWarrior myWarrior;
	bool bWarrior=true;

	if(false == myWarrior.open())
	{
		cout << "Can only print data! Please, make sure that an IOWarrior 40 is connected at start time!" << endl;
		myWarrior.printState();
		bWarrior=false;
	}
	while(false ==myWarrior.buttonInput())
	{

		myWarrior.buttonInput();

		}
	cout << "button pressed.. starting light!!"<<endl;
				iow_runningLight_test();
}
void button_test_2()
{
	cout << "button test 2... press button to shift the light" << endl;
	CIOWarrior myWarrior;
	myWarrior.open();
	myWarrior.printState();


	char data=0x01;
	while (true==myWarrior.open() && data !=0x00)
	{
		myWarrior.write(data);
		while (false==myWarrior.buttonInput())
		{

		}

		data <<= 1;
		cout<< "button pressed true";
	}
	myWarrior.close();
	cout<< "end";
}
void button_test_3()
{
	cout << "button test 3... press button to start, pause and resume running light" << endl;
	CIOWarrior myWarrior;
	if(false == myWarrior.open())
	{
		cout << "Can only print data! Please, make sure that an IOWarrior 40 is connected at start time!" << endl;
		myWarrior.printState();
	}

	char data=1;
	bool button=false;
	for(int i=0;i<10;i++)
	{
		while(button==false)
		{
			//wait for input to start running light.
			button=myWarrior.buttonInput();
		}
		if(button==true){

			//button pressed... start running light
			button=false;
			while(button==false)
			{
				//running light till next button is pressed
				myWarrior.write(data);
				Sleep(250);
				data=data << 1;
				if(0==data)data=1;
				button=myWarrior.buttonInput();
			}
			if(button==true)
			{
				// button pressed and running light is paused.. return to initial loop to start the light
				button = false;
			}

		}
	}
}

void CAmpmeter_test_1()
{
	CIOWarrior mywarrior;
	CAmpMeter mymeter;
	bool warrior=true;
	if (false==mywarrior.open())
	{
		mywarrior.printState();
		warrior=false;
	}
	mymeter.init(-50,100,SCALING_MODE_LIN,-30,&mywarrior);
	char data=-100;
	for(int i=0;i<100;i++)
	{
		if(false==warrior ||false==mymeter.write(data))
		{
			mymeter.print(data);
			mywarrior.open();
		}
		Sleep(100);
		data+=1;
	}
	mywarrior.close();
}

void CAmpmeter_test_2()
{
	CIOWarrior myWarrior;
	CAmpMeter ampmeter;
	cout<<"Initializing Amp-Meter!"<<endl;

ampmeter.init(0,1,SCALING_MODE_LIN,-30, &myWarrior);
bool bWarrior=true;
float bsize[50];
//srand((unsigned)time(NULL));
for(int i=0;i<50;i++)
{
	bsize[i]=((double) rand()/ (RAND_MAX));
	cout<<bsize[i]<<endl;
	Sleep(500);
	if(false==myWarrior.open())
	{
		cout<<" can only print data please,make sure that IOWarrior is connected at the start";
		myWarrior.printState();
		bWarrior=false;
	}
	if(false==bWarrior)
	{
		ampmeter.print(bsize[i]); // print LED data, no device connected at start time
	}
	else if (false==ampmeter.write(bsize[i]))  // if write fails tested by unplugging and plugging
			{
		ampmeter.print(bsize[i]);
		myWarrior.open();           // try to reopen the device
			}
	}
float* i1;
i1=max_element(bsize,bsize+50);
float data=float(*i1);
ampmeter.write(data);
cout<<" highest data is :"<< data<<endl;
Sleep(500);
myWarrior.close();
}

