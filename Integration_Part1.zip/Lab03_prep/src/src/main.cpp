////////////////////////////////////////////////////////////////////////////////
// Header
#define USE_MATH_DEFINES
#include <cmath>
#include <iostream>
#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
using namespace std;

#include "CFile.h"
#include "CASDDException.h"
#include "CFilterFile.h"
#include "CSoundfile.h"
#include "CAudioOutputStream.h"
#include "CFilter.h"



// test routines
void parseFilterFileTest();
// prototypes

void Lab03_soundFileTest(string sndfile_r); 										// test case function task 1
void Lab03_soundFileFilterTest(string sndfile_r, string sndfile_w, string fltfile); // test case function task 2
void Lab03_FilterOptimizeTest(string sndfile_r, string sndfile_w); 					// test case function task 3

int main (void)
{
	setvbuf(stdout, NULL, _IONBF, 0);
	cout << "Lab03 started." << endl << endl;

		// check if the folders fit your file structure on hard disk
		string sndfolder="E:\\MSC- Darmstadt\\Advanced software Design and Development\\ASDD_Module\\Sounds\\";
		string fltfolder="E:\\MSC- Darmstadt\\Advanced software Design and Development\\ASDD_Module\\workspace\\Lab03_prep\\src\\files\\";

		string sndextension=".wav";
		string fltextension=".txt";

		// change to use another sound, filter type or filter
		string snd="hey";								 // sound file to use in the test
		string flttype="butter";						 // filter type to use in the test "butter", "trebleBoost", "delay"
		string fltname="yulewalk_treble_boost_Order6"; 		 // name of the filter file written by Matlab

		string sndfile_r=sndfolder+snd+sndextension; // file to read
		string sndfile_w=sndfolder+snd+"_"+flttype+"_filtered"+sndextension;
		string fltfile=fltfolder+fltname+fltextension;


		//Lab03_soundFileTest(sndfile_r);
		//Lab03_soundFileFilterTest(sndfile_r,sndfile_w,fltfile);
		//Lab03_FilterOptimizeTest(sndfile_r, sndfile_w);

	parseFilterFileTest();

    cout << "Bye!" << endl;
	return 0;
}

// Read the special ASDD filter file format (should be done by a special filter file class)
bool getFilter(FILE* pFile, int fs, string& type, int& N, string& info, float*& bbuf, int& blen, float*& abuf, int& alen);
void parseFilterFileTest()
{
	// open file
	const char* filename="E:\\MSC- Darmstadt\\Advanced software Design and Development\\ASDD_Module\\workspace\\Lab03_prep\\src\\files\\2000Hz_lowpass_Order6.txt";
	FILE* pFile=fopen(filename, "r");
	if(pFile == NULL)
	{
		cout << filename << ": file not found!" << endl;
		return;
	}

	int fs=44100, N=0, blen=0, alen=0;
	string type, info;
	float* b=NULL;
	float* a=NULL;
	bool bgot=getFilter(pFile, fs, type, N, info, b, blen, a, alen);

	cout << endl << "header: type=" << type << " Order=" << N << " Info=" << info << endl;

	cout << "fs=" << fs << endl;
	if(bgot && (a!=NULL) && (b!=NULL))
	{
		cout << "b=";
		for(int i=0;i<blen;i++)
			cout << b[i] << "\t";
		cout << endl  << "a=";
		for(int i=0;i<alen;i++)
			cout << a[i] << "\t";
		cout << endl;
		delete[]b;
		delete[]a;
	}
	else
		cout << "No coefficients found for fs!"<< endl;

	fclose(pFile);
}
bool getFilter(FILE* pFile, int fs, string& type, int& N, string& info, float*& bbuf, int& blen, float*& abuf, int& alen)
{
	if(pFile==NULL)return false;

	// get the header
	int sbufsize=360;
	char sbuf[sbufsize];
	fgets(sbuf, sbufsize, pFile);

	// parse the header
	string s=sbuf;
	N=0;	// order (number)
	int pos=0,end=0;
	end=s.find(";",pos);
	type= s.substr(pos, end-pos);
	pos=end+1;
	end=s.find(";",pos);
	string sorder= s.substr(pos, end-pos);
	N=stoi(sorder);
	info=s.substr(end+1);

	// read data
	int i, fsr;
	while( NULL != fgets(sbuf, sbufsize, pFile))
	{
		fsr=stoi(sbuf);			// find fs
		if(fs!=fsr)
		{
			char* pgot=sbuf;
			while(pgot)			// skip b coefficients
			{
				pgot=fgets(sbuf, sbufsize, pFile);
				if(NULL != strrchr(sbuf,'\n'))break; // end of line has been read
			}
			while(pgot)	// skip a coefficients
			{
				pgot=fgets(sbuf, sbufsize, pFile);
				if(NULL != strrchr(sbuf,'\n'))break;
			}
		}
		else
		{
			bbuf=new float[N+1];
			abuf=new float[N+1];
			char sep;
			for(i=0; i<N+1;i++)
			{
				if(EOF==fscanf(pFile,"%f%c",&bbuf[i],&sep))
					break;
				if(sep == '\n')
					break;
			}
			blen=i;
			if(sep!='\n')fscanf(pFile,"%c",&sep);
			for(i=0; i<N+1;i++)
			{
				if(EOF==fscanf(pFile,"%f%c",&abuf[i],&sep))
					break;
				if(sep == '\n')
					break;
			}
			alen=i;
			if(sep!='\n')fscanf(pFile,"%c",&sep);
			return true;
		}
	}
	return false;
}

void Lab03_soundFileTest(string sndfile_r)
{
	// copy the audio file play test function code (Lab02 task 1) here.
	// Adapt it:
	// - use an CSoundFile object for sound file handling
	// - use the sound file name passed as a parameter to the function;
	//SF_INFO sfinfo;

	CSoundFile soundFile(sndfile_r.c_str(),FILE_READ);
	soundFile.open();

	// print file info
	cout << "File: " << sndfile_r << "[fs=" << soundFile.getSampleRate() << "Hz, Channels=";
	cout << soundFile.getNumChannels() << ", total number of frames=" << soundFile.getNumFrames() << "]" << endl;

	// configure sample buffer
	int framesPerBlock=(int)(soundFile.getSampleRate()/8); // 1s/8=125ms per block
	int sblockSize=soundFile.getNumChannels()*framesPerBlock; // total number of samples per block
	float* sbuf=new float[sblockSize];


	// reads the number of frames passed (1 frame == 1 for mono, 2 for stereo, channel number in general)
	int readSize=soundFile.read(sbuf, framesPerBlock);


	CAudioOutputStream audiooutput;
	audiooutput.open(soundFile.getSampleRate(),soundFile.getNumChannels(),8,sbuf,readSize);


	while( framesPerBlock == readSize)
	{

		audiooutput.start();

		readSize = soundFile.read(sbuf, framesPerBlock);

	}

	soundFile.close();

	delete[]sbuf;
}
void Lab03_soundFileFilterTest(string sndfile_r, string sndfile_w, string fltfile)
{

	CAudioOutputStream myAudioStream;

	string soundfile = sndfile_r;
	CSoundFile mySoundFile(soundfile.c_str(),FILE_READ);
	mySoundFile.open();

	CSoundFile mySoundFileWrite(sndfile_w.c_str(),FILE_WRITE);
	mySoundFileWrite.openW(mySoundFile.getNumChannels(),mySoundFile.getSampleRate());

	CFilterFile myFilterFile(fltfile.c_str(), 1, mySoundFile.getSampleRate());
	myFilterFile.open();

	int filterBufsize=1060;
	char* fbuf=new char[filterBufsize];
	myFilterFile.read(fbuf,filterBufsize);

	myFilterFile.print();

	CFilter myFilter(myFilterFile.getDenCo(),myFilterFile.getNumCo(),myFilterFile.getN(),mySoundFile.getNumChannels());
	// configure sample buffer

	int framesPerBlock=(int)(mySoundFile.getSampleRate()/8); // 1s/8=125ms per block // framesPerBlock
	int sblockSize=mySoundFile.getNumChannels()*framesPerBlock; // total number of samples per block //sblockSize

	float* sbuf1=new float[sblockSize];
	float* sbuf2 = new float[sblockSize]; // new buffer for filtered signal

	myAudioStream.open(mySoundFile.getSampleRate(),mySoundFile.getNumChannels(),8, sbuf2, sblockSize);

	int readSize = mySoundFile.read(sbuf1, framesPerBlock);
	cout<<*sbuf1<<endl;

	while( framesPerBlock == readSize)
	{
		// 1. filter the soundtrack, 2. write filtered part into a new file, 3. play the filtered track
		myFilter.filter(sbuf1, sbuf2,framesPerBlock);
		mySoundFileWrite.write(sbuf2,framesPerBlock);
		myAudioStream.start();
		readSize = mySoundFile.read(sbuf1, framesPerBlock);
	}

	myAudioStream.close();

	mySoundFileWrite.close();

	mySoundFile.close();
	delete[]sbuf1;
	delete[]sbuf2;
	delete[]fbuf;
}
void Lab03_FilterOptimizeTest(string sndfile_r, string sndfile_w)
{
	CAudioOutputStream myAudioStream;

		string soundfile = sndfile_r;
		CSoundFile mySoundFile(soundfile.c_str(),FILE_READ);
		mySoundFile.open();

		CSoundFile mySoundFileWrite(sndfile_w.c_str(),FILE_WRITE);
		mySoundFileWrite.openW(mySoundFile.getNumChannels(),mySoundFile.getSampleRate());

		CFilter test4(0.5, 0.75, 50, mySoundFile.getSampleRate(),mySoundFile.getNumChannels());
		//int numFrames=mySoundFile.getNumFrames();

		int framesPerBlock=(int)(mySoundFile.getSampleRate()/8); // 1s/8=125ms per block
		int sblockSize=mySoundFile.getNumChannels()*framesPerBlock; // total number of samples per block

		float* sbuf=new float[sblockSize];
		float* sbuf1=new float[sblockSize];

		myAudioStream.open(mySoundFile.getSampleRate(),mySoundFile.getNumChannels(),8, sbuf1, sblockSize);

		int readSize=mySoundFile.read(sbuf, framesPerBlock);

		while( framesPerBlock == readSize)

			{
				// 1. filter the soundtrack, 2. write filtered part into a new file, 3. play the filtered track
				test4.filterDelay(sbuf, sbuf1,framesPerBlock);
				mySoundFileWrite.write(sbuf1,framesPerBlock);

				myAudioStream.start();
				readSize = mySoundFile.read(sbuf, framesPerBlock);
			}

		myAudioStream.start();
		myAudioStream.stop();

		myAudioStream.close();

		mySoundFileWrite.close();

		mySoundFile.close();
		delete[]sbuf;
		delete[]sbuf1;


}
