/*
 * CFilter.cpp
 *
 *  Created on: 11.09.2019
 *      Author: Wirth
 */
#include <math.h>
#include "CASDDException.h"
#include "CFilter.h"
#include <iostream>
using namespace std;

CFilter::CFilter(float* ca, float* cb, int order, int channels)
{
	m_order=abs(order);
	m_channels=abs(channels);
	m_firstZ=0;

	if((m_order!=0) && (m_channels!=0))
	{
		// buffer for the intermediate filter states from last sample
		m_z=new float[m_channels*(m_order+1)];
		for(int i=0;i < m_channels*(m_order+1);i++){m_z[i]=0.;}

		if((ca!=NULL) && (cb!=NULL))
		{
			m_a=new float[m_order+1];
			m_b=new float[m_order+1];
			for(int i=0;i<=m_order;i++)
			{
				m_a[i]=ca[i]/ca[0];
				m_b[i]=cb[i]/ca[0];
			}
		}
		else
			throw CASDDException(SRC_Filter, -1, "Filter coefficients not available!");
	}
	else
		throw CASDDException(SRC_Filter, -1, "Filter order and channels must not be zero!");
}
/**
 * Creates a delay filter (to implement for Task 2)
*/
CFilter::CFilter(float gFF, float gFB, int delay_ms, int fs, int channels)
{
	m_order=(int)(abs(delay_ms)*abs(fs)/1000.);
	m_channels=abs(channels);
	m_firstZ=0;
	m_z=new float[m_channels*(m_order+1)];
	float m_gFF=gFF;
	float m_gFB=gFB;
   m_a=new float[m_channels+1];
    m_b=new float[m_channels+1];
	if((m_order!=0) && (m_channels!=0))
	{
	// to do
		m_b[0]=1;
		m_b[1]=(m_gFF-m_gFB);
		m_a[0]=1;
		m_a[1]=(-m_gFB);
	}
	else
		throw CASDDException(SRC_Filter, -1, "Filter order and channels must not be zero!");
}

CFilter::~CFilter()
{
	if(m_a!=NULL)
		delete[]m_a;
	if(m_b!=NULL)
		delete[]m_b;
	if(m_z!=NULL)
		delete[]m_z;
}

void CFilter::reset()
{
	m_firstZ=0;
	for(int i=0;i < m_channels*(m_order+1);i++)
	{
		m_z[i]=0.;
	}
}


bool CFilter::filter(float* x, float* y, int framesPerBuffer)
{
	if((framesPerBuffer < m_order) || (x == NULL) || (y == NULL))
		return false;

	int bufsize=framesPerBuffer*m_channels;
	for(int k=0; k < bufsize; k+=m_channels)
	{
		for(int c=0;c<m_channels;c++)
		{
			y[k+c]=m_b[0]*x[k+c]+m_z[0+c];
		}
		for(int n=1; n <= m_order; n++)
		{
			for(int c=0;c<m_channels;c++)
				m_z[m_channels*(n-1)+c]=m_b[n]*x[k+c]+m_z[m_channels*n+c]-m_a[n]*y[k+c];
		}
	}
	return true;
}

/**
 * implements a delay filter (to implement for Task 2)
*/
bool CFilter::filterDelay(float* x, float* y, int framesPerBuffer)
{

	if((framesPerBuffer < m_order) || (x == NULL) || (y == NULL))
		return false;
	// to do
	int bufsize=framesPerBuffer*m_channels;
	/*for(int k=0; k < bufsize; k+=m_channels)
	{
		for(int c=0;c<m_channels;c++)
		{
			y[k+c]=x[k+c]+m_z[0+c];
		}
		for(int n=1; n <= m_order; n++)
		{
			for(int c=0;c<m_channels;c++)
				m_z[m_channels*(n-1)+c]=m_b[1]*x[k+c]+m_a[1]*y[k+c];
		}
			}*/

	for(int k=0; k < bufsize; k+=1)
				{

						y[k]=x[k]+m_z[(m_firstZ%(m_channels*(m_order+1)))];
						m_z[(m_firstZ%(m_channels*(m_order+1)))] = m_b[1]*x[k] + (m_a[1]*y[k]);
					m_firstZ = m_firstZ + 1;

				}



	return true;
}
