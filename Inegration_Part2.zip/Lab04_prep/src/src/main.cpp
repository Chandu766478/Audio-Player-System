////////////////////////////////////////////////////////////////////////////////
// Header
#define USE_MATH_DEFINES
#include <cmath>
#include <iostream>
#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>			// functions to scan files in folders (used in Lab04prep_DBAdminInsert)
using namespace std;

#include "CFile.h"
#include "CFilterFile.h"
#include "CASDDException.h"
#include "CDatabase.h"
#include "CFilterDB.h"
#include "CsoundDB.h"
#include "CSoundFile.h"
#include "CAudioOutputStream.h"
#include "CFilter.h"
#include "sndfile.h"


// Lab preparation: test routines
void Lab04prep_FilterFileTest(string fltfile);		// adapted file format test
void Lab04prep_DBAdminInsert(string fltfolder);
void Lab04prep_insertFilterTest(string fltfile);
void Lab04prep_SoundDBFilesTest();
void Lab03_soundFileTest(string sndfile_r);
void Lab04_task1();
void Lab04_insertSoundFile(string sndfolder);

int main (void)
{
	setvbuf(stdout, NULL, _IONBF, 0);
	cout << "Lab04prep started." << endl << endl;

	// check if the folders fit your file structure on hard disk
	string sndfolder="E:\\MSC- Darmstadt\\Advanced software Design and Development\\ASDD_Module\\Sounds\\";
	string fltfolder="E:\\MSC- Darmstadt\\Advanced software Design and Development\\ASDD_Module\\workspace\\Lab04_prep\\src\\files\\";
	string sndextension=".wav";
	string fltextension=".txt";

	// files for the tests
	string fltname="2000Hz_lowpass_butter_Order6"; 	// name of the filter file written by Matlab
	//string fltname="gFF500_gFB500delay_feedback_delay50"; 	// name of the filter file written by Matlab
	string snd="hey";								// sound file to use in the test

	// Lab04 prep: Task 1
	//Lab04prep_FilterFileTest(fltfolder+fltname+fltextension);
	//Lab04prep_DBAdminInsert(fltfolder);
	//Lab04prep_insertFilterTest(fltfile);
	//Lab04prep_SoundDBFilesTest();
	Lab04_task1();

	//Lab04_insertSoundFile(sndfolder);

    cout << "Bye!" << endl;
	return 0;
}

// Read and print the modified special ASDD filter file format
void Lab04prep_FilterFileTest(string fltfile)
{
	// open file
	int rbufsize=100;
	char readbuf[rbufsize];
	try
	{
		int fs1=16000, fs2=8000;
		CFilterFile ff1(fltfile.c_str(), FILE_READ, fs1), ff2(fltfile.c_str(), FILE_READ, fs2);
		cout<<fltfile;
		ff1.open();
		if(ff1.read(readbuf,rbufsize))
			ff1.print();
		else
			cout << "No coefficients available for fs=" << fs1 << "Hz" << endl;
		ff1.close();

		cout << endl;
		ff2.open();
		if(ff2.read(readbuf,rbufsize))
			ff2.print();
		else
			cout << "No coefficients available for fs=" << fs2 << "Hz" << endl;
		ff2.close();
	}
	catch(CASDDException& e)
	{
		e.print();
	}
}

// get all filter files from a directory
void Lab04prep_DBAdminInsert(string fltfolder)
{
	 dirent* entry;
	 DIR* dp;
	 string fltfile;

	 try
	 {
		 dp = opendir(fltfolder.c_str());
		 if (dp == NULL) throw CASDDException(SRC_File,-1,"Could not open filter file folder.");
		 while((entry = readdir(dp)))
		 {
			 fltfile=entry->d_name;

			 if(fltfile.rfind(".txt")!=string::npos)
			 {
				 cout << " filter file to insert into the database. ";
				 Lab04prep_insertFilterTest(fltfolder+fltfile);
			 }
			 else
				 cout << " irrelevant file of other type or directory";
		     cout << endl;
		 }
		 closedir(dp);
	 }
	 catch(CASDDException& e)
	 {
		 if(e.getSource() == SRC_Database)
			 return;
		 e.print();
	 }
}

// insert the filter data from the files into the database
void Lab04prep_insertFilterTest(string fltfile)
{
	// Database object
	CFilterDB mydb;
	int rbufsize=100;
	char readbuf[rbufsize];
	try
	{
		if(false == mydb.open("AudioFilterCollectionDB","root"))
			throw CASDDException(SRC_Database,-1,"Could not open database AudioFilterCollectionDB");

		// get all sampling frequencies contained in the file
		int numFs=rbufsize;
		int fsbuf[rbufsize];
		CFilterFile::getFs(fltfile,fsbuf,numFs);

		for(int i=0; i < numFs;i++)
		{
			CFilterFile ff(fltfile.c_str(), FILE_READ,fsbuf[i]);
			ff.open();
			if(ff.read(readbuf,rbufsize))
			{
				ff.print();
				mydb.insertFilter(ff.getType(),ff.getsubType(),
								  fsbuf[i],ff.getN(),1000*ff.getdeInsec(),ff.getInfo(),
								  ff.getNumCo(),ff.getNumlen(),ff.getDenCo(),ff.getDenlen());
			}
			else
				cout << "No coefficients available for fs=" << fsbuf[i] << "Hz" << endl;
			ff.close();
		}
		mydb.close();
	}
	catch(CASDDException& e)
	{
		e.print();
		if(e.getSource() == SRC_Database)
			throw e;
	}
}
void Lab04prep_SoundDBFilesTest(){
	// Database object
		CsoundDB mydb;
		//int userinput;
		try
		{
			if(false == mydb.open("SoundCollectionDB","root"))
				throw CASDDException(SRC_Database,-1,"Could not open database SoundCollectionDB");

			//mydb.insertSound("Sounds","funnysong",16000,2);
			//cout<<"A row is being updated successfully" <<endl;

			//cout<< "please select a sound file to get its frequency" << endl;
			mydb.selectAllSounds();
			while (mydb.fetch())
			{
				cout << mydb.getSoundfileid() <<"\t" << mydb.getFilename() << endl;
			}
			//mydb.closeQuery();
			//cin >> userinput;
			//cout<<endl;
			//cout<<mydb.selectFsBySfid(userinput);
			//cout<<mydb.getSamplingfrequency()<<endl;
		}
		catch(CASDDException& e)
			{
				e.print();
				if(e.getSource() == SRC_Database)
					throw e;
			}
}

void Lab03_soundFileTest(string sndfile_r)
{
	// copy the audio file play test function code (Lab02 task 1) here.
	// Adapt it:
	// - use an CSoundFile object for sound file handling
	// - use the sound file name passed as a parameter to the function;
	//SF_INFO sfinfo;

	CSoundFile soundFile(sndfile_r.c_str(),FILE_READ);
	soundFile.open();

				// print file info
				cout << "File: " << sndfile_r << "[fs=" << soundFile.getSampleRate() << "Hz, Channels=";
				cout << soundFile.getNumChannels() << ", total number of frames=" << soundFile.getNumFrames() << "]" << endl;

				// configure sample buffer
				int framesPerBlock=(int)(soundFile.getSampleRate()/8); // 1s/8=125ms per block
				int sblockSize=soundFile.getNumChannels()*framesPerBlock; // total number of samples per block
				float* sbuf=new float[sblockSize];


				// reads the number of frames passed (1 frame == 1 for mono, 2 for stereo, channel number in general)
				int readSize=soundFile.read(sbuf, framesPerBlock);


				CAudioOutputStream audiooutput;
				audiooutput.open(soundFile.getSampleRate(),soundFile.getNumChannels(),8,sbuf,readSize);


				while( framesPerBlock == readSize)
				{

					audiooutput.start();
					readSize = soundFile.read(sbuf, framesPerBlock);

				}

					soundFile.close();

					delete[]sbuf;
}
void Lab04_task1()
{
	CAudioOutputStream myAudio;
	CFilterDB applyFilter;
	CsoundDB mySound;

          try
          	{
          		if(false == mySound.open("SoundCollectionDB", "root"))
          			throw CASDDException(SRC_Database,-1,"Could not open database SoundCollectionDB");

          		if(false == applyFilter.open("AudioFilterCollectionDB", "root"))
          			throw CASDDException(SRC_Database,-1,"Could not open database SoundCollectionDB");
          	}
          	catch(CASDDException &e)
          	{
          		e.print();
          		if(e.getSource() == SRC_Database)
          			throw e;
          	}

          	mySound.selectAllSounds();
          				while (mySound.fetch())
          				{
          					cout << mySound.getSoundfileid() <<"\t" << mySound.getFilename() << endl;
          				}
          				mySound.closeQuery();
          	int userinput;
          	cin >> userinput;
          	mySound.selectFsBySfid(userinput);

          	//mySound.fetch();
          	//cout<<Folderpath<<endl;
          	//cout<<filenamefromDB<<endl;
          	//cout << filepath << endl;
          	//mySound.closeQuery();

          	if(true == applyFilter.selectFilters(mySound.getSamplingfrequency()))
          	{
          		while(applyFilter.fetch())
          		{
          			cout << applyFilter.getFilterID() << " " << " " << applyFilter.getFilterType() << " " << applyFilter.getFilterSubType() << " " << endl;

          		}
          		applyFilter.closeQuery();
          	}

          	int filterID;
          	cout << "select the filter ID ";
          	cin >> filterID;
          	//applyFilter.selectFilterData(filterID);
          	//applyFilter.fetch();

          	string Folderpath = mySound.getFilefolder();
          	string filenamefromDB = mySound.getFilename();
          	string filepath = Folderpath + filenamefromDB + ".wav";
          	CSoundFile mySoundFile(filepath.c_str(),FILE_READ);
          	mySoundFile.open();

          	int framesPerBlock=(int)(mySound.getSamplingfrequency()/8);               // 1s/8=125ms per block
          	int sblockSize=mySound.getNoofchannels()*framesPerBlock;             // total number of samples per block
          	float* sbuf=new float[sblockSize];
          	//float* sbuf1 = new float[sblockSize];
          	cout<<*sbuf<<endl;

          	if(filterID == -1)
          	{

          		int readSize=mySoundFile.read(sbuf, framesPerBlock);

          		myAudio.open(mySound.getSamplingfrequency(),mySound.getNoofchannels(),8,sbuf,readSize);

          		//myAudio.start();

          		while( framesPerBlock == readSize)
          		{
          			myAudio.start();
          			readSize = mySoundFile.read(sbuf, framesPerBlock);
          		}

          		myAudio.stop();
          		myAudio.close();
          		mySoundFile.close();

          		delete[]sbuf;
          	}

          	else{

          		applyFilter.selectFilterData(filterID);

          		// object for filter file
          		CFilter myFilter(applyFilter.getACoeffs(),applyFilter.getBCoeffs(),applyFilter.getOrder(),mySound.getNoofchannels());
          		cout<<"Filter coeficients are :"<<*applyFilter.getBCoeffs()<<endl;
          		cout<<"THe final filter choosen is :"<<applyFilter.getFilterInfo();

          		float* sbufFilter=new float[sblockSize];
          		          	float* sbuf1 = new float[sblockSize];


          		// open audio stream with details from sound file
          		myAudio.open(mySound.getSamplingfrequency(),mySound.getNoofchannels(),8,sbuf1,sblockSize);

          		int readSize=mySoundFile.read(sbufFilter, framesPerBlock);
          		cout<<*sbufFilter<<" "<< *sbuf1<<" "<<framesPerBlock<<" "<< readSize<<" " <<sblockSize<<endl;

          		while( framesPerBlock == readSize)
          		{

          			myFilter.filter(sbufFilter, sbuf1,framesPerBlock);
          			myAudio.start();
          			readSize = mySoundFile.read(sbufFilter, framesPerBlock);
          			cout<<*sbufFilter<<endl;
          		}


          		myAudio.stop();

          		myAudio.close();

          		mySoundFile.close();

          		delete[]sbufFilter;
          		delete[]sbuf1;
          	}

}
void Lab04_insertSoundFile(string sndfolder){
	// Database object
	CsoundDB Sounddb;
	dirent* entry;
	DIR* dp;
	string sndfile;
	dp = opendir(sndfolder.c_str());
	if (dp == NULL) throw CASDDException(SRC_File,-1,"Could not open filter file folder.");
	try
	{
		if(false == Sounddb.open("SoundCollectionDB","root"))
			throw CASDDException(SRC_Database,-1,"Could not open database AudioFilterCollectionDB");

		while((entry = readdir(dp)))
		{
			sndfile=entry->d_name;
			cout << sndfile << ":";
			if(sndfile.rfind(".wav")!=string::npos)
			{
				cout << " sound file to insert into the database. ";

				string soundfolder = sndfolder.c_str()+sndfile;
				cout<<sndfolder;
				CSoundFile mySoundFile(soundfolder.c_str(),FILE_READ);

				mySoundFile.open();
				Sounddb.insertSound("E:\\\\MSC- Darmstadt\\\\Advanced software Design and Development\\\\ASDD_Module\\\\Sounds" ,sndfile.c_str(),mySoundFile.getSampleRate(),mySoundFile.getNumChannels());
				mySoundFile.close();
			}
			else
				cout << " irrelevant file of other type or directory";
			cout<<sndfile<<endl;
			cout << endl;
		}
		closedir(dp);
	}
	catch(CASDDException& e)
	{
		if(e.getSource() == SRC_Database)
			return;
		e.print();
	}
}

