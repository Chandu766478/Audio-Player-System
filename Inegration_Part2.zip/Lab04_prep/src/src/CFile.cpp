/*
 * File.cpp
 *
 *  Created on: 14.11.2019
 *      Author: A. Wirth
 */
#include <iostream>
#include <string.h>
using namespace std;

#include "CFile.h"
#include "CASDDException.h"

/**
 * Constructor
 */
CFile::CFile(const char* path, int mode) {
	m_path=path;
	if((mode==FILE_UNKNOWN) || ((mode!=FILE_READ) && (mode!=FILE_WRITE) && (mode!=FILE_WRITEAPPEND)))
		mode=FILE_READ|FILE_WRITEAPPEND;
	else
		m_mode=mode;
}

CFile::~CFile() {
}

void CFile::print(void)
{
	cout << "CFile[" << hex << (int)m_mode << dec << "]: " << m_path << endl;
}

/**
 * utility method to get textual description for the error codes
 */
string CFile::getErrorTxt(ASDD_FILEERRORS e) {
	switch(e)
	{
	case FILE_E_UNKNOWNOPENMODE: return string("unknown file open mode");
	case FILE_E_NOFILE: return string("file not found");
	case FILE_E_FILENOTOPEN: return string("file not open");
	case FILE_E_NOBUFFER: return string("no data buffer available");
	case FILE_E_CANTREAD: return string( "file has been opened in write only mode");
	case FILE_E_READ: return string("error during read");
	case FILE_E_CANTWRITE: return string("file has been opened in read only mode");
	case FILE_E_WRITE: return string("error during write");
	case FILE_E_SPECIAL: return string("special file type error");
	default:return string("unknown error");
	}
}

CRawFile::CRawFile(const char* path, int mode)
: CFile(path, mode)
{
	m_pFile=NULL;
}

CRawFile::~CRawFile() {
	close();
}

void CRawFile::open() {
	string mode;
	if(((m_mode & FILE_WRITE) != 0) && ((m_mode & FILE_WRITEAPPEND) != 0))mode="a+";
	else if((m_mode & FILE_WRITE) != 0)mode="w";
	else if((m_mode & FILE_WRITEAPPEND) != 0)mode="a";
	else if((m_mode & FILE_READ) != 0)mode="r";
	else throw CASDDException(SRC_File, FILE_E_UNKNOWNOPENMODE, getErrorTxt(FILE_E_UNKNOWNOPENMODE));

	m_pFile=fopen(m_path.c_str(),mode.c_str());
	if(m_pFile == NULL)throw CASDDException(SRC_File, FILE_E_NOFILE, getErrorTxt(FILE_E_NOFILE));
}

void CRawFile::close() {
	if(m_pFile != NULL)
		fclose(m_pFile);
	m_pFile=NULL;
}

int CRawFile::read(char* buf, int bufsize) {
	if(m_pFile == NULL)throw CASDDException(SRC_File, FILE_E_FILENOTOPEN,getErrorTxt(FILE_E_FILENOTOPEN));
	if((buf == NULL) || (bufsize == 0))throw CASDDException(SRC_File, FILE_E_NOBUFFER,getErrorTxt(FILE_E_NOBUFFER));
	if((m_mode & FILE_READ) == 0)throw CASDDException(SRC_File, FILE_E_CANTREAD,getErrorTxt(FILE_E_CANTREAD));

	int szread= fread(buf, 1, bufsize, m_pFile);
	if((szread != bufsize) && (feof(m_pFile) == 0))
		throw CASDDException(SRC_File, FILE_E_READ,getErrorTxt(FILE_E_READ));
	return szread;
}

void CRawFile::write(char* buf, int bufsize)
{
	if(m_pFile == NULL)throw CASDDException(SRC_File, FILE_E_FILENOTOPEN,getErrorTxt(FILE_E_FILENOTOPEN));
	if(buf == NULL)throw CASDDException(SRC_File, FILE_E_NOBUFFER,getErrorTxt(FILE_E_NOBUFFER));
	if(((m_mode & FILE_WRITE) == 0) && ((m_mode & FILE_WRITEAPPEND) == 0))throw CASDDException(SRC_File, FILE_E_CANTWRITE,getErrorTxt(FILE_E_CANTWRITE));

	int szwrite= fwrite(buf, 1, bufsize, m_pFile);
	if(szwrite != bufsize)
	{
		close();
		throw CASDDException(SRC_File, FILE_E_WRITE,getErrorTxt(FILE_E_WRITE));
	}
}

void CRawFile::print(void)
{
	cout << "CRawFile[" << hex << m_pFile << dec << "]" << endl;
	CFile::print();
}

