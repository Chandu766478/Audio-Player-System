/*
 * CFilterFile.h
 *
 *  Created on: Dec 8, 2019
 *      Author: CHANDU-PM
 */

#ifndef SRC_CFILTERFILE_H_
#define SRC_CFILTERFILE_H_

#include "CFile.h"
#include "CASDDException.h"

class CFilterFile : public CRawFile
{
	int m_fs;                  // Sampling frequency parameter
	int m_N;                   // Filter order parameter
	int m_blen, m_alen;       // Length of numerator and denominator coefficients
	string m_type, m_info,m_subtype;        // Filter type and filter info
	float* m_a;                    // Filter coefficients
	float* m_b;
	float m_deInsec;

public:

	CFilterFile(const char * path, const int mode, const int fs);

	virtual ~CFilterFile();
	static void getFs(string path, int* fs, int& numFs);

	int getFs() const;
	int getN() const;

	int read(char* buf, int bufsize);
	void print(void);

	int getDenlen() const;
	int getNumlen() const;

	const string& getInfo() const;
	const string& getType() const;
	const string&getsubType()const;

	float* getDenCo() const;
	float* getNumCo() const;
	float getdeInsec()const;


};



#endif /* SRC_CFILTERFILE_H_ */
