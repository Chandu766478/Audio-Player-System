/*
 * File.h
 *
 *  Created on: 14.11.2019
 *      Author: A. Wirth
 */

/**
 * \file CFile.h
 *
 * header file for class CFile (differs slightly from the class used within the lesson!)
 *
 * \see CFile
 */
#ifndef FILE_H_
#define FILE_H_

#include <string>
using namespace std;

/**
 * base class for files
 *
 * defines an interface for the operations open, close and read
 * has methods to print basic informations to the console window
 * and to retrieve textual messages for the file error codes
 *
 */
/**
 * \brief available file open modes (may be combined logically to express e.g. ReadWrite mode)
 */
enum ASDD_FILEMODES{FILE_UNKNOWN=0x00, FILE_READ=0x01, FILE_WRITE=0x02, FILE_WRITEAPPEND=0x04};
/**
 * \brief Error Codes
 */
enum ASDD_FILEERRORS{FILE_E_UNKNOWNOPENMODE,FILE_E_NOFILE,FILE_E_FILENOTOPEN,FILE_E_NOBUFFER,FILE_E_READ,FILE_E_CANTREAD,FILE_E_CANTWRITE,FILE_E_WRITE,FILE_E_SPECIAL};

class CFile {
protected:
	/**
	 *\brief file open mode
	 */
	unsigned char m_mode;
	/**
	 *\brief file name with absolute or relative path
	 */
	string m_path;

public:
	/**
	 *\brief constructor sets the complete file path and the open mode
	 *\param path [in] complete relative or absolute file path and name
	 *\param mode [in] file open mode shall be a logical combination of ASDD_FILEMODES
	 */
	CFile(const char* path=NULL, const int mode=FILE_UNKNOWN);
	virtual ~CFile();

/**
 * this class defines an interface for all file classes
 * the following methods are pure virtual that is, they are not implemented
 * in the base class and each derived class has to implement these methods
 */
	/**
	 *\brief opens a file
	 */
	virtual void open()=0;
	/**
	 *\brief closes a file
	 */
	virtual void close()=0;
	/**
	 *\brief  reads the content of the file into a buffer
	 *\brief  returns the number of elements read
	 *\params buf[in] - address of a buffer to store the data
	 *\params bufsize[in] - size of the buffer in bytes
	 */
	virtual int read(char* buf, int bufsize)=0;

	/**
	 *\brief   prints the content of the file on console
	 *\brief   is not pure virtual that is, it is implemented in this class
	 *\brief   and may be used or overwritten by the derived classes
	 */
	virtual void print(void);

protected:
	/**
	 *\brief converts the file error codes into textual messages
	 */
	string getErrorTxt(ASDD_FILEERRORS e);
};

/**
 * class to read and write files without any format
 * derived from CFile
 * implements the interface for the operations open, close and read
 * implements an additional method for writing files
 * overloads the basic classes print method
 */
class CRawFile : public CFile
{
protected:
	/**
	 *\brief  File pointer (is NULL, until the file has been opened successfully)
	 */
	FILE* m_pFile;
public:
	CRawFile(const char * path, const int mode=FILE_UNKNOWN);
	virtual ~CRawFile();

	/**
	 * opens a file
	 */
	virtual void open();
	/**
	 * closes a file
	 */
	virtual void close();
	/**
	 * reads the content of the file (implements the interface)
	 */
	virtual int read(char* buf, int bufsize);
	/**
	 *\brief  writes the content of the buffer into a file
	 *\brief  returns the number of elements read
	 *\params buf[in] - address of a buffer to store the data
	 *\params bufsize[in] - size of the buffer in bytes
	 */
	virtual void write(char* buf, int bufsize);
	/**
	 * prints content of file on console
	 */
	virtual void print(void);
};

#endif /* FILE_H_ */
