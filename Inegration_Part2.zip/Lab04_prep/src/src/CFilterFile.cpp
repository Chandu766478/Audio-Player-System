/*
 * CFilterFile.cpp
 *
 *  Created on: Dec 8, 2019
 *      Author: CHANDU-PM
 */

#include <iostream>
#include <string.h>
using namespace std;

#include "CFilterFile.h"
#include "CFile.h"


CFilterFile::CFilterFile(const char* path, const int mode, const int fs):CRawFile(path,mode)
{
	m_fs=fs;                  // Initializing Sampling frequency
		m_N=0;
		// Intitializing number of numerator and denominator coefficients
		m_blen=0;
		m_alen=0;

		// Initializing type and information of filter
		m_type="";
		m_subtype="";
		m_info="";
		// giving filter coefficients
		m_a=NULL;
		m_b=NULL;
		m_deInsec=0;
}

CFilterFile::~CFilterFile()
{
	close();
		if(m_a!=NULL)delete []m_a;
		if(m_b!=NULL)delete []m_b;

}

int CFilterFile::read(char* buf, int bufsize)
{
	if(m_pFile == NULL)throw CASDDException(SRC_File, FILE_E_FILENOTOPEN,getErrorTxt(FILE_E_FILENOTOPEN));
		if((buf == NULL) || (bufsize == 0))throw CASDDException(SRC_File, FILE_E_NOBUFFER,getErrorTxt(FILE_E_NOBUFFER));
		if((m_mode & FILE_READ) == 0)throw CASDDException(SRC_File, FILE_E_CANTREAD,getErrorTxt(FILE_E_CANTREAD));
		if(NULL==fgets(buf, bufsize, m_pFile))throw CASDDException(SRC_File, FILE_E_READ,getErrorTxt(FILE_E_READ));

		// parse the header
		string s=buf;
		int pos=0,end=0;
		end=s.find(";",pos);
		m_type= s.substr(pos, end-pos);
		pos=end+1;
		end=s.find(";",pos);
		m_subtype= s.substr(pos, end-pos);    // Lab04 subtype
		pos=end+1;
		end=s.find(";",pos);
		string sorder= s.substr(pos, end-pos);
		m_N=stoi(sorder);
		string sdelay = s.substr(pos, end-pos);
		m_deInsec = atof(sdelay.c_str());
		m_info=s.substr(end+1);
		// read data
		int i, fsr;
		while( NULL != fgets(buf, bufsize, m_pFile))
		{
			fsr=stoi(buf);			// find fs
			if(m_fs!=fsr)
			{
				char* pgot=buf;
				while(pgot)			// skip b coefficients
				{
					pgot=fgets(buf, bufsize, m_pFile);
					if(NULL != strrchr(buf,'\n'))break; // end of line has been read
				}
				while(pgot)	// skip a coefficients
				{
					pgot=fgets(buf, bufsize, m_pFile);
					if(NULL != strrchr(buf,'\n'))break;
				}
			}
			else
			{
				m_b=new float[m_N+1];
				m_a=new float[m_N+1];
				char sep;
				for(i=0; i<m_N+1;i++)
				{
					if(EOF==fscanf(m_pFile,"%f%c",&m_b[i],&sep))
						break;
					if(sep == '\n')
						break;
				}
				m_blen=i;
				if(sep!='\n')fscanf(m_pFile,"%c",&sep);
				for(i=0; i<m_N+1;i++)
				{
					if(EOF==fscanf(m_pFile,"%f%c",&m_a[i],&sep))
						break;
					if(sep == '\n')
						break;
				}
				m_alen=i;
				if(sep!='\n')fscanf(m_pFile,"%c",&sep);

				return 1;
			}
		}
		return 0;

}

int CFilterFile::getFs() const
{
	return m_fs;
}

int CFilterFile::getN() const
{
	return m_N;
}

void CFilterFile::print(void)
{
	CRawFile::print();
		cout<<endl;
		if((m_a!=NULL) && (m_b!=NULL))
		{
			cout << m_type << m_subtype<< " Filter [Order = " << m_N << ", fs = " << m_fs<< "] " << m_info << endl;

			cout << m_deInsec<< "Coefficients b = { ";
			for(int numco=0;numco<m_blen;numco++)
			{
				if(numco!=0)
					cout<<"\t";
				cout << m_b[numco];
			}
			cout <<" }"<< endl  << "Coefficients a = { ";
			for(int denco=0;denco<m_alen;denco++)
			{
				if(denco!=0)
					cout<<"\t";
				cout << m_a[denco];
			}
			cout <<" }"<< endl;
		}
		else
			cout << "No coefficients found for fs ="<< m_fs <<endl;
}

int CFilterFile::getNumlen() const
{
	return m_blen;
}

int CFilterFile::getDenlen() const
{
	return m_alen;
}

const string& CFilterFile::getInfo() const
{
	return m_info;
}

const string& CFilterFile::getType() const
{
	return m_type;
}

float* CFilterFile::getDenCo() const
{
	return m_a;
}

const string& CFilterFile::getsubType() const {

	return m_subtype;
}

float* CFilterFile::getNumCo() const
{
	return m_b;
}
void CFilterFile::getFs(string path, int* fs, int& numFs)
{
	FILE* pFile=fopen(path.c_str(),"r");
	if(pFile==NULL)throw CASDDException(SRC_File, FILE_E_FILENOTOPEN,"Can't open file for reading sample rates!");
	int bufsize=100;
	char buf[bufsize];

	// skip the header
	do
	{
		fgets(buf, bufsize, pFile);
	}while(NULL == strrchr(buf,'\n'));

	// read fs
	int i=0;
	while( (NULL != fgets(buf, bufsize, pFile)) && (numFs > i))
	{
		fs[i++]=stoi(buf);			// store fs
		for(int j=0; j < 2; j++)	// skip coefficients
		{
			do
			{
				fgets(buf, bufsize, pFile);
			}while(NULL == strrchr(buf,'\n'));
		}
	}
	numFs=i;
	fclose(pFile);
}

float CFilterFile::getdeInsec() const {

	return m_deInsec;
}
