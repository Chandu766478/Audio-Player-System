//////////////////////////
// ASDD Lab
// Database base class - to access databases via ODBC API

#ifndef CDatabase_H	
#define CDatabase_H

#include <windows.h>
#include <sql.h>
#include <sqlext.h>

#define DB_TEXTLEN 255
enum DB_STATE{DB_S_NOTREADY, DB_S_CONNECTED, DB_S_FETCH}; // states of the database object

class CDatabase
{
protected:
	SQLHENV m_hDBEnv;		// Environment Handle
	SQLHDBC m_hDBC;			// Connection Handle
	SQLHDBC m_hStmt;		// Statement Handle
	long long	m_info;			// value for bindcol and fetch
	DB_STATE m_eState;		// current state of the database object

public:
//////////////////////////////////////////////////////////////////////////////
//Methods, usable for any database
	CDatabase();
	~CDatabase();
	
	// open a database
	// Parameter: 
	// pDB ... name of the data source (like registered in the ODBC driver / OS)
	// pUsr ... user name
	// pPwd ... password (if entered at registration)
	bool open(const char* pDB, const char* pUsr=NULL, const char* pPwd=NULL);

	// fetches one record from the database (used after select statements)
	// returns:
	// true .... new data available
	// false ... no more data available oder es ist ein Fehler aufgetreten (in diesem Fall wird eine
	//           Fehlermeldung auf dem Bildschirm angezeigt)
	bool fetch();	

	// beendet eine Datenbank-Aktion, muss zum Abschluss jeder Datenbankaktion (select, insert, delete, update, ...) 
	// aufgerufen werden 
	void closeQuery();					
	
	// schlie�t die Datenbank
	void close();						

	// zeigt den aktuellen Zustand der Datenbankverbindung und den zuletzt aufgetretenen Fehler an
	void showState();


protected:
	// execute SQL statement
	bool _executeSQLStmt(string sSQLStmt, string errText, bool isSelectStmt, bool bPrintStmt=false);
	// wird in den Methoden der DB-Klasse f�r die Anzeige des zuletzt aufgetretenen Fehlers aufgerufen
	void _showSQLError( const char* infotxt, SQLRETURN rc, SQLHANDLE hndl, int type);
	// retrieves the native error code
	int _getNativeErrorCode(SQLRETURN rc, SQLHANDLE hndl, int type);
};	
#endif

